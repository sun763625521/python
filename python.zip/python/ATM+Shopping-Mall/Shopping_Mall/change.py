# -*-coding:utf-8-*-
# Author:sunhao

def shopping():
    print('shopping mall')

def test():
    print('test')