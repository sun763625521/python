# -*-coding:utf-8-*-
# Author:sunhao

import os,sys,json,time

BASE_DIR=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
print(BASE_DIR)

"""数据库文件相对路径"""

__db_product = BASE_DIR + r"\database\product_list"
__db_shopping_car = BASE_DIR + r"\database\shopping_car"
__db_users_dict = BASE_DIR + r"\database\users_dict"
__db_credit_card_dict = BASE_DIR + r"\database\credit_card_dict"
__db_shopping_record = BASE_DIR + r"\database\shopping_record"
__db_credit_card_record = BASE_DIR + r"\database\credit_card_record"



def Shopping_mall():
    shopping_list=[]
    pro_list=[]
    with open(__db_product,'r') as f_product:
        for item in f_product:
            pro_list.append(item.split())

    def pro_info():
        print("编号\t\t\t商品\t\t价格")
        for index,item in enumerate(pro_list):
            print("%s\t\t%s\t\t%s" % (index, item[0], item[1]))

    while True:

        print("\33[32;0m目前商城在售的商品信息\33[0m".center(40, "-"))
        pro_info()
        choice_id=input("\n\33[34;0m选择要购买的商品编号 【购买 ID】/【返回 b】\33[0m：")
        if choice_id.isdigit():
            choice_id=int(choice_id)
            if choice_id <len(pro_list) and choice_id >=0:
                pro_item=pro_list[choice_id]
                print("\33[31;0m商品%s加入购物车 价格%s\33[0m" % (pro_item[0], pro_item[1]))
                shopping_list.append(pro_item)
                #print(shopping_list)
            else:
                print("\33[31;0m错误：没有相应的编号 请重新输入:\33[0m\n")

        elif choice_id == "b":
            with open(__db_shopping_car,'r+') as f_shopping_car:
                list=json.loads(f_shopping_car.read())
                list.extend(shopping_list)
                print(list)
                f_shopping_car.seek(0)
                f_shopping_car.truncate()  # 清空__db_shopping_car文件
                list=json.dumps(list)
                f_shopping_car.write(list)
            break


        else:
            print("\33[31;0m错误：没有相应的编号 请重新输入:\33[0m\n")



def Empty_shopping_car():

    with open(__db_shopping_car,'w') as f_shopping_car:
        list=json.dumps([])
        f_shopping_car.write(list)


def Shopping_car():
    while True:
        with open(__db_shopping_car,'r+') as f_shopping_car:
            list=json.loads(f_shopping_car.read())
            print(list)
            sum = 0
            print("\33[32;0m购物车信息清单\33[0m".center(40,"-"))
            for index,item in enumerate(list):
                print(index,item[0],item[1])
                sum+=int(item[1])

            print("\33[31;1m商品总额共计： %s\33[0m"%sum)

        if_buy = input("\n\33[34;0m选择要进行的操作 返回【b】/清空【f】\33[0m:")
        if if_buy == 'b':
            break
        if if_buy == 'f':
            Empty_shopping_car()



def shopping_car_record(current_user,value):
    with open(__db_shopping_record,'r+') as f_shopping_car_record:
        record_dict=json.loads(f_shopping_car_record.read())
        month=time.strftime("%Y-%m-%d",time.localtime())
        times = time.strftime("%H:%M:%S",time.localtime())
        print(record_dict.keys())
        if str(current_user) not in record_dict.keys():
            record_dict[current_user]={month:{times:value}}    #初次购物记录为零时  这步非常关键
        else:
            if month not in record_dict[current_user].keys():
                record_dict[current_user][month]={times:value}
            else:
                record_dict[current_user][month][times]=value

        dict=json.dumps(record_dict)
        f_shopping_car_record.seek(0)
        f_shopping_car_record.truncate()
        f_shopping_car_record.write(dict)








def cat_shopping_record(current_user):
    while True:
        print("\33[32;0m用户 %s 购物记录\33[0m".center(40, "-")%current_user)
        with open(__db_shopping_record,"r+") as f_shopping_record:
            shopping_record_dict = json.loads(f_shopping_record.read())
            if current_user not in shopping_record_dict.keys():
                print("\33[31;0m用户 %s 还没有进行过消费\33[0m\n" %current_user)
            else:
                data=sorted(shopping_record_dict[current_user])
                for d in data:
                    times = sorted(shopping_record_dict[current_user][d])
                    for t in times:
                        print("\33[31;0m【时间】 %s %s\33[0m" % (d, t))
                        items = shopping_record_dict[current_user][d][t]
                        print("\33[31;0m【商品】 【价格】\33[0m")
                        for v in items:
                            print("\33[31;0m %s\t\t%s\33[0m" % (v[0], v[1]))

            if_back = input("\n\33[34;0m是否返回 返回【b】\33[0m:")
            if if_back == "b":
                break








def Auth_credit_card(credit_card):
    with open(__db_credit_card_dict,'r+') as f_credit_card_dict:
        credit_card_dict=json.loads(f_credit_card_dict.read())
        passwd=input("\33[34;0m当前信用卡【%s】 请输入支付密码：\33[0m:"%credit_card)
        if passwd==credit_card_dict[credit_card]['password']:
            return True
        else:
            print("\33[31;0m密码输入错误，支付失败\33[0m")







def Pay_shopping(current_user):

    while True:
        sum=0
        print("\33[32;0m购物结算\33[0m".center(40, "-"))
        with open(__db_shopping_car,'r') as f_shopping_car:
            list=json.loads(f_shopping_car.read())
            for item in list:
                print(item[1])
                sum+=int(item[1])
            if_pay = input("\n\n\33[34;0m当前商品总额：%s \n是否进行支付 确定【y】/返回【b】\33[0m:"%sum)
            if if_pay == 'y':
                with open(__db_users_dict,'r') as f_user_dict:
                    user_dict=json.loads(f_user_dict.read())
                    credit_card=user_dict[current_user]["creditcard"]
                    # print("--------------------%s------------------------"%credit_card)
                    if credit_card == 0:
                        print("\33[31;0m账号 %s未绑定信用卡，请到个人中心里修改信用卡绑定\33[0m\n"%(current_user))

                    else:
                        with open(__db_credit_card_dict,'r+') as f_credit_card_dict:
                            credit_card_dict=json.loads(f_credit_card_dict.read())
                            # print(credit_card_dict,credit_card_dict[credit_card]['limit'])
                            limit = credit_card_dict[credit_card]["limit"]
                            limit_new=limit-sum
                            # print(limit_new)
                            if limit_new>=0:
                                res=Auth_credit_card(credit_card)
                                if res == True:
                                    credit_card_dict[credit_card]['limit']=limit_new
                                    dict=json.dumps(credit_card_dict)
                                    f_credit_card_dict.seek(0)
                                    f_credit_card_dict.truncate()
                                    f_credit_card_dict.write(dict)
                                    print("\33[31;1m支付成功，当前余额 %s元\33[0m\n" % (limit_new))
                                    shopping_car_record(current_user,list)
                                    Empty_shopping_car()

                            else:
                                print("\33[31;0m当前信用卡额度 %s元 不足矣支付购物款 可绑定其他信用卡支付\33[0m\n"%limit)

            if if_pay == 'b':
                break




def update_password(current_user):

    while True:
        print("\33[32;0m修改登录密码\33[0m".center(40, "-"))
        print("当前账号：\t%s\n当前密码：\t**\n" %current_user)
        if_update=input("\33[34;0m是否要修改 % s登录密码 确定【y】/返回【b】\33[0m:"%(current_user))
        if if_update=='y':
            with open(__db_users_dict,'r+') as f_user_dict:
                user_dict=json.loads(f_user_dict.read())
                passwd=user_dict[current_user]["password"]
                old_passwd=input("\33[34;0m输入原来的密码\33[0m:")
                if old_passwd == passwd:
                    new_passwd=input("\33[34;0m输入新的密码\33[0m:")
                    agin_passwd=input("\33[34;0m再输入新的密码\33[0m:")
                    if new_passwd==agin_passwd:
                        user_dict[current_user]["password"]=new_passwd
                        dict=json.dumps(user_dict)
                        f_user_dict.seek(0)
                        f_user_dict.truncate()
                        f_user_dict.write(dict)
                        print("\33[31;1m密码修改成功\33[0m\n")

                    else:
                        print("\33[31;0m两次密码不一致\33[0m\n")


                else:
                    print("\33[31;0m密码不正确\33[0m\n")

        if if_update=="b":
            break




def update_info(current_user):
    while True:
        print("\33[32;0m修改个人资料\33[0m".center(40, "-"))
        with open(__db_users_dict,'r+') as f_user_dict:
            user_dict=json.loads(f_user_dict.read())
            address=user_dict[current_user]["address"]
            print("当前账号：\t%s\n当前收货地址：\t%s\n" % (current_user, address))
            if_update=input("\33[34;0m是否要修改 % s收货地址 确定【y】/返回【b】\33[0m:" % current_user)
            if if_update=="y":
                new_address=input("\33[34;0m输入新的收货地址\33[0m:")

                user_dict[current_user]["address"]=new_address

                dict=json.dumps(user_dict)

                f_user_dict.seek(0)
                f_user_dict.truncate()
                f_user_dict.write(dict)

            elif if_update=="b":
                break




def Link_creditcard(current_user):
    while True:
        print("\33[32;0m修改信用卡绑定\33[0m".center(40, "-"))
        with open(__db_users_dict,'r+') as f_user_dict:

            user_dict=json.loads(f_user_dict.read())
            credit_card=user_dict[current_user]["creditcard"]

            if credit_card==0:
                print("当前账号： \t%s" %current_user)
                print("信用卡绑定：\33[31;0m未绑定\33[0m\n")
            else:
                print("当前账号： \t%s" % current_user)
                print("绑定的信用卡： %s\n" % credit_card)

            if_update=input("\33[34;0m是否要修改信用卡绑定 确定【y】/返回【b】\33[0m:")

            if if_update=="y":

                credit_card_new=input("\33[34;0m输入新的信用卡卡号(6位数字)\33[0m:")
                if credit_card_new.isdigit() and len(credit_card_new) == 6:

                    with open(__db_credit_card_dict,'r+') as f_credit_card:
                        credit_card=json.loads(f_credit_card.read())
                        if credit_card_new in credit_card.keys():
                            user_dict[current_user]["creditcard"]=credit_card_new
                            dict=json.dumps(user_dict)
                            f_user_dict.seek(0)
                            f_user_dict.truncate()
                            f_user_dict.write(dict)
                            print("\33[31;1m信用卡绑定成功\33[0m\n")

                        else:
                            print("\33[31;0m输入信用卡卡号不存在(未发行)\33[0m\n")

                else:
                    print("\33[31;0m输入信用卡格式错误\33[0m\n")



            elif if_update=="b":
                break




