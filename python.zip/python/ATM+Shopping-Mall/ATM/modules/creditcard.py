# -*-coding:utf-8-*-
# Author:sunhao
def test2():
    print('test2')