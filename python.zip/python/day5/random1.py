# -*-coding:utf-8-*-
# Author:sunhao
import random

print(random.random()) #用于生成一个0到1的随机符点数: 0 <= n < 1.0

print(random.randint(1,10))  #随机1-10之间整数

print(random.randrange(1,3))


print(random.choice("alex"))
