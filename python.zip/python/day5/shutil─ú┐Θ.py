# -*-coding:utf-8-*-
# Author:sunhao
import shutil

# f1=open('test','w+')
#
# f1.write('this is text')
#
#
#
# f2=open('test2','r+')
#
#
# shutil.copyfileobj(f1,f2)
# shutil.copyfile('test2','test3')
#
#
# shutil.rmtree('模块1')
shutil.copyfile('test','test4')
shutil.copy('test','test5')
shutil.copystat('test','test4')
shutil.copytree()