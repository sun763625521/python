# -*-coding:utf-8-*-
# Author:sunhao
import random

check_code=''

for i in range(4):
    current=random.randrange(0,5)
    if current==i:
        tmp=chr(random.randrange(65,90))
    else:
        tmp=random.randint(0,9)

    check_code+=str(tmp)

print(check_code)




