# -*-coding:utf-8-*-
# Author:sunhao
import re

res=re.match("^D.+3$","DChen123ronghua123")
#
#res=re.search('r[a-zA-Z]+a',"Chen123ronGhua123a")
#
# print(res.group())
#
#res=re.findall("[1-9]{1,3}","1a2nad345dsv")



#res=re.search("(?P<province>[0-9]{2})(?P<city>[0-9]{2})(?P<birthday>[0-9]{4})","371481199306143242").groupdict("birthday")
# '''{'province': '3714', 'city': '81', 'birthday': '1993'}'''
print(res.group())