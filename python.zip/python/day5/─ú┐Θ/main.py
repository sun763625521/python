# -*-coding:utf-8-*-
# Author:sunha


# import sys,os
# print(sys.path)
#
# base=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
# sys.path.insert(0,base)
# print(sys.path)

import module
# from module import logger
# logger()
# print(module.name)
def logger():
    module.logger()
    print('in the test')

def search():
    module.logger()
    print('in the search')

logger()
search()