# -*-coding:utf-8-*-
# Author:sunhao
'''
1.定义：用来从逻辑上组织python代码(变量，函数，类，逻辑)，本质就是.py结尾的python文件,实现一个功能
包：python package 用来从逻辑上组织模块  本质就是一个目录(必须带有一个__init__.py的文件)

2.导入方法： import module
import module1,module2   导入多个模块
from module import *   导入所有  慎用
from module  import  logger as logger_sunhao   创建别名
from module import m1,m2,m3

3.import模块本质(路径搜索和搜索路径)
就是把python文件解释一遍
导入包的本质就是执行该包下的__init__文件

import module ---> module.py ----> module.py的路径---》sys.path

4.导入优化：

5.模块的分类：
1.标准库
time与datetime

2.开源模块

3.自定义模块
'''

name='sunhao'
def sayhello():
    print(name)

def logger():
    print('logger_sunhao')

