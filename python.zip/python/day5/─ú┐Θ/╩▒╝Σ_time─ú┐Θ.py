# -*-coding:utf-8-*-
# Author:sunhao
import time


print(time.time())
print(time.clock())
print(time.process_time())
print(time.altzone)
print(time.asctime())
print(time.localtime())
print(time.gmtime(time.time()-8000))
