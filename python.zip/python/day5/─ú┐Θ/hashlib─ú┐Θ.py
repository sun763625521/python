# -*-coding:utf-8-*-
# Author:sunhao

import hashlib,hmac

m1=hashlib.md5()

m1.update(b"hello")

print(m1.hexdigest())
m1.update(b"it is me")  #更新 第二次update是与第一次update拼接起来

print(m1.hexdigest())

m2=hashlib.md5()

m2.update(b"helloit is me")
print(m2.hexdigest())

s1=hashlib.sha1()
s1.update(b"hello")
print(s1.hexdigest())
s1.update(b"it is me")
print(s1.hexdigest())

s2=hashlib.sha1()
s2.update(b"helloit is me")
print(s2.hexdigest())


m3=hashlib.md5()

m3.update("天王盖地虎".encode(encoding="utf-8"))

print(m3.hexdigest())



h=hmac.new("你是二百五".encode(encoding='utf-8'))

print(h.hexdigest())