# -*-coding:utf-8-*-
# Author:sunhao

from package_test import test

test.test1()