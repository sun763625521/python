# -*- coding:utf-8 -*-
class SweetPotato:
    def __init__(self):
        self.cookedString='生的'
        self.cookedLevel=0


    def __str__(self):
        return '地瓜的状态:%s(%d)'%(self.cookedString,self.cookedLevel)

    def cook(self,cook_time):
        self.cookedLevel += cook_time
        if self.cookedLevel >=0 and self.cookedLevel <3:
            self.cookedString='生的'
        elif self.cookedLevel >=3 and  self.cookedLevel < 5:
            self.cookedString="半生不熟"
        elif self.cookedLevel >=5 and self.cookedLevel <8:
            self.cookedString='熟了'



di_gua=SweetPotato()
di_gua.cook(6)
print di_gua