# -*-coding:utf-8-*-
# Author:sunhao
def print_name(name,age,id,country='CN'):
    print('姓名：',name)
    print('年龄:',age)
    print('id',id)
    print('国籍',country)

print_name(19,20,'李四')