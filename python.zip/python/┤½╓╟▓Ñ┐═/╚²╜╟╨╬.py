# -*- coding:utf-8 -*-

i=1
while i <= 10:  # 打印十行
    j=1
    while j <= i:  # 每行打印i个元素
        print ('$',end='')
        j+=1

    i += 1
    print ("")