def get_num(num):
    if num>1:
       return  num*get_num(num-1)
    else:

        return num

result=get_num(9)

print (result)



