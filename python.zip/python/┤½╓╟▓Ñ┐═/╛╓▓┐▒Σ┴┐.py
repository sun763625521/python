a=100

def test1():
    a=50
    print('a=%d'%a)
def test2():
    print('a=%d'%a)


test1()
test2()


names=['Jim','Tom','Rain']

def change_name():
    names[0]='王者荣耀'
    print('--函数里面--',names)

change_name()
print(names)





def calc(n):
    print(n)
    if int(n / 2) == 0:
        return n
    return calc(int(n / 2))


calc(10)











