#-*- coding:utf-8 -*-

func=lambda a,b:a+b


print func(1,2)

status=[{'name':'sunhao','age':18},{'name':'lisi','age':19},{'name':'wangwu','age':20}]
print status
status.sort()
print status

def test(a,b,func):
    result=func(a,b)
    print result
#func_new=eval(raw_input('请输入一个匿名函数：'))
#test(11,22,func_new)


a=4
b=5
print a,b
a=a+b
b=a-b
a=a-b
print a,b