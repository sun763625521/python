def test(a,b,*tt,**t1):
    print a
    print b
    print tt
    print t1
    result=a+b
    for num in tt:
        result+=num
    print result

test(1,2,23,45,
     name='sunhao')