# -*- coding:utf-8 -*-
i=1
while i <= 5:  # 打印十行
    j=1
    while j <= 5:  # 每行打印五个元素
        print "$",
        j+=1
    i += 1
    print ''