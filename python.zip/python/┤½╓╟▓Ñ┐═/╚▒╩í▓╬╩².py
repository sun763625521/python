def test(a,b=22):
    result = a+b
    print '%d'%result

test(11,b=44)

def sum_num(a,b,*args):
    result=a+b
    for num in args:
        result+=num
    print result



trupt=(11,22,33,44)
print trupt[0]
for num in trupt:
    print num


def zidian(a,b,*args,**kwargs):
    print a
    print b
    print args
    print kwargs

A=(1,2,3,4)
B={'name':'sunhao','age':18}
zidian(1,2,3,4,56,*A,**B)

