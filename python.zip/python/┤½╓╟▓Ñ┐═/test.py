# -*- coding:utf-8 -*-

def print_trangle():
    print ('=====================')
    i=1
    while i<10:
        j=0
        while j<i:
            print ('*',end='')
            j+=1
        i+=1
        print('')
    print ('======================')
print_trangle()