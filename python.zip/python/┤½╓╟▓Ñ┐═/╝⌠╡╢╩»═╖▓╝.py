#-*- coding:utf-8 -*-
import random
num=int(input('请输入：剪刀(0) 石头(1) 布(2): '))
computer=random.randint(0,2)
if (num==0 and computer==2) or (num==1 and computer == 0 ) or (num==2 and computer==1):
    print ('haha 你赢了了')
elif num==computer:

    print ('平局')
else:
    print('你输了')
