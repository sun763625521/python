# -*- coding:utf-8 -*-
list=[]
# 打印功能
def print_menu():
    print '名片管理系统 v9'
    print '1 添加一个名片',
    print '2 删除一个名片',
    print '3 修改一个名片',
    print '4 查找一个名片'
    print '5 退出系统'

def card_info():

    new_name = raw_input('请输入名字: ')
    new_age = raw_input('请输入年龄: ')
    new_addr = raw_input('请输入地址: ')
    dict = {'name': new_name, 'age': new_age, 'addr': new_addr}
    list.append(dict)
    print list

def find_card():

    flag = 0
    find_name = raw_input('请输入你要查找的名字: ')
    for temp in list:
        if temp['name'] == find_name:
            flag = 1
            print '恭喜你找到了'
            print '%s\t%s\t%s\t' % (temp['name'], temp['age'], temp['addr'])

            break
    if flag == 0:
        print'查无此人'

print_menu()



def main():
    '''完成对整个程序的控制'''
    while True:
        print''
        num=int(raw_input('请输入序号: '))
        if num==1:
            card_info()

        elif num==2:
            pass
        elif num==3:
            pass
        elif num==4:
            find_card()


        elif num==5:
            print '退出系统'
            break
        else:
            print '请重新输入一个1-4的号码:'
main()