# -*- coding:utf-8 -*-
class Cat:

    def __init__(self):




    def eat(self):
        print 'cat is eating fish.'

    def drink(self):
        print 'cat is drinking.'

    def introduce(self):
        print '%s的年龄是%d' % (self.name, self.age)


# 创建一个对象
tom = Cat()
tom.eat()
tom.name='lam'
tom.age=18
tom.introduce()

ll=Cat()
ll.name='aa'
ll.age=21
ll.introduce()

