# -*- coding:utf-8 -*-
num1=int(raw_input('please input a number: '))
num2=int(raw_input('please input a number again: '))
num3=int(raw_input('pleaase input a number'))

def sum_num(a,b,c):
    result=a+b+c
    return result

def aver_num(a,b,c):
    result=sum_num(a,b,c)/3

    return result

def squr_num(a,b,c):
    result=aver_num(a,b,c)**2
    print 'the square is %d'%result



squr_num(num1,num2,num3)

