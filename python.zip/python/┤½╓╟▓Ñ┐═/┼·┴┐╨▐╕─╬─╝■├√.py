# -*-coding:utf-8 -*-
import os
# 1.获取一个文件夹的文件名
folder_name = raw_input('请输入你要找的文件夹名字: ')
# 2.获取那个文件夹中所有文件的名字
file_names = os.listdir(folder_name)
# 3.对获取的名字进行重命名修改
os.chdir(folder_name)
for name in file_names:
    print name
    os.rename(name,'华谊出品-'+name)
