a=100
def test():
    a=10
    print ('a=%d'%a)

test()
print (a)
