# -*- coding:utf-8 -*-
stu_a = {'name':'A','age':18,'gender':1,'hometown':'河北'}
stu_b= {'name':'B','age':20,'gender':1,'hometown':'河南'}

def stu_intro(stu):
    for key,value in stu.items():
        print 'key=%s,value=%s'%(key,value)


stu_intro(stu_a)
