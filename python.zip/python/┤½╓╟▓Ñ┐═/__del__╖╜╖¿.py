# -*- coding:utf-8 -*-
# Author:sunhao

class Dog:
    def __del__(self):
        print("game over")




dog=Dog()
del dog


print('============')

