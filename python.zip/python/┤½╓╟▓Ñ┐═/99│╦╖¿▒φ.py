# -*- coding:utf-8 -*-

i = 1
while i <= 9:  # 打印十行
    j = 1
    while j <= i:  # 每行打印i个元素
        print '%d*%d=%d\t'%(j,i,j*i),
        j += 1

    i += 1
    print ''