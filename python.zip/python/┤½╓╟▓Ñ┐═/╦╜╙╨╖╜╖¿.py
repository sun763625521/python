# -*- coding:utf-8 -*-
# Author:sunhao
class Dog:




    def __send_msg(self):
        print("----正在发送短信----")

    def send_msg(self,money):
        if money >100:

            self.__send_msg()
        else:
            print('余额不足')



dog=Dog()
dog.send_msg(1000)
