# -*- coding:utf-8 -*-
# Author:SunHao

class factory:

    def __init__(self,new_area,new_info,new_addr):
        self.area = new_area
        self.info = new_info
        self.addr = new_addr
        self.left_area=new_area
        self.content_items=[]
    def __str__(self):
        return "房子的总面积是：%d,可用面积是：%s,户型是：%s,地址是：%s,物品：%s"%(self.area, self.left_area,self.info, self.addr,self.content_items)



    def Add_item(self,item):
        self.left_area-=item.get_area()
        self.content_items.append(item.get_name())


class Bed:
    def __init__(self,new_name,new_area):
        self.name=new_name
        self.area=new_area

    def __str__(self):

        return "%s占用的面积是%d"%(self.name,self.area)

    def get_area(self):
        return self.area
    def get_name(self):
        return self.name



fangzi = factory(129,'三室两厅','北京')
print(fangzi)

bed1=Bed("席梦思",4)
print(bed1)

fangzi.Add_item(bed1)
print(fangzi)

bed2=Bed("三人床",5)

fangzi.Add_item(bed2)
print(fangzi)
