# -*- coding:utf-8 -*-
i=1
sum=0
num=0
while i <= 100:


    if i%2==0:
        sum=sum+i
        num+=1
        print i
    i+=1
    if num==20:
        break



print '1到100的和为:%d.'%(sum)