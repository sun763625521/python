# -*-coding:utf-8-*-
# Author:sunhao
#经典类与新式类的区别  继承方法上的不同 广度优先和深度优先  两种继承策略  从python3开始都是广度优先  python2是深度优先
# class People：经典类
class People(object):                 #新式类
    def __init__(self,name,age):
        self.name=name
        self.age=age
        print("people")

    def eat(self):
        print("%s is eating"%self.name)

    def sleep(self):

        print("%s is sleeping"%self.name)

    def print_tab(self):
        print("%s 今年 %s"%(self.name,self.age))

    # def __del__(self):
    #     print('game over')


class Relation(object):
    # def __init__(self):
    #     print("relation")

    def make_friend(self,obj):
        print("%s is making friends with %s"%(self.name,obj.name))



class Man(Relation,People):

    def __init__(self,name,age,money):
        People.__init__(self,name,age)    #重构  经典类写法
        #super(Man,self).__init__(name,age)  #新式写法
        self.money=money
        print('money')

    def drink(self):
        print("%s is drinking %s"%(self.name,self.money))


    def sleep(self):
        People.sleep(self)
        print("man is sleeping")


class Women(Relation,People):

    def get_birth(self):

        print("%s is making face"%self.name)





# p1=People("小明",50)
# p1.sleep()
#
m1=Man("Jim",20,100)
m1.sleep()
# m1.eat()
#
# m1.sleep()
# m1.drink()
#
# #
# w1=Women("lucy",20)
# w1.get_birth()
#
#
# m1.make_friend(w1)


