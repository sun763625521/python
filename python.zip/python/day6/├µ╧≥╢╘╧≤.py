# -*-coding:utf-8-*-
# Author:sunhao
# 类
# 对象
#面向对象三大特性：
# 封装
# 继承
# 多态
#
# class Dog:
#     def __init__(self,name):
#         self.name=name
#
#
#     def bulk(self):
#         print('%s,汪汪'%self.name)
#
#
#
# d1 = Dog("成立")
# d2 = Dog("李思思")
#
# d1.bulk()
# d2.bulk()

class Role(object):

    n=123       #类变量  大家都可以调用
    n_list=['a']

    def __init__(self, name, role, weapon, life_value=100, money=15000,*args):  #构造函数 在实例化时做一些类的初始化的工作

        self.name = name     #self.name赋给实例   实例变量(静态属性)  作用域就是实例本身
        self.role = role
        self.weapon = weapon
        self.__life_value = life_value
        self.money = money
        self.args=args

    def __del__(self):  #析构函数

        print("%s 彻底死了。。。。"%self.name)



    def print_args(self):

        print(self.args)

    def shot(self):
        print("shooting...")

    def got_shot(self):               #类的方法(功能)   (动态属性)
        print("ah...,I got shot...")

    def buy_gun(self,gun_name):
        print("%s just bought %s" %(self.name,gun_name))

    def show_lif(self):

        print("life %s"%self.__life_value)



r1=Role('Jim','police',"AK47")

# r1.n=456
#
# print(r1.n)
# print(r1.n,r1.name)
# print(r1.n_list)
r1.n_list[0]='r1'
#
print(r1.n_list)
 #生成一个角色 (初始化一个类，造了一个对象) 把一个类变成一个具体对象的过程叫实列化  相当于 Role(r1,'Alex','police','AK47') r1.name=name
 #
 # r2 = Role('Jack', 'terrorist', 'B22')  #生成一个角色

r3=Role('lucy','artist','AK47')
#print(r3.n,r3.name)

# r3.n=100
#
# Role.n=789
#
# print(r1.n,r3.n)
r3.n_list[0]='r2'
r3.n_list.append('r3')
print(r3.n_list)
#r3.print_args()
# print(r3.money)
#
#
# print(isinstance(r3,Role))

# r1.buy_gun('AK-47')
#
#
#
# r2.buy_gun('加特林')

print(Role.n_list)
print(r1.n_list)
# # r1.n_list.append('test1')
# # print(r1.n_list)
# # r2.n_list.append('test2')
# # print(Role.n_list)
# # #
#r1.n=456
#print(r1.n)
#
# print(r2.n)
# print(r1.n_list)
# print(r2.n_list)

#析构函数：在实例释放或销毁的时候自动执行，通常用于做一些收尾工作 如：关闭一些数据库连接，打开的临时文件  程序结束的时候回自动回收内存


# r1.got_shot()
# r1.show_lif()


