# -*-coding:utf-8-*-
# Author:sunhao

class school(object):

    def __init__(self,name,addr):
        self.name=name
        self.addr=addr
        self.students=[]
        self.teachers=[]

    def enroll(self,stu_obj):
        print('为%s学员办理注册手续'%stu_obj.name)
        self.students.append(stu_obj)


class SchoolMember(object):
    def __init__(self,name,age,sex):
        self.name=name
        self.age=age
        self.sex=sex






class Teacher(SchoolMember):

    def __init__(self,name,age,sex,salary,course):
        super(Teacher,self).__init__(name,age,sex)
        self.salary=salary
        self.course=course

    def tell(self):
        print("""-------info of Teacher:---------
               name:%s
               age:%s
               sex:%s
               salary:%s
               course=%s
         """ % (self.name, self.age, self.sex, self.salary, self.course))

    def teach(self):
        print("%s is teaching course[%s]"%(self.name,self.course))





class Student(SchoolMember):

    def __init__(self,name,age,sex,stu_id,grade):
        super(Student,self).__init__(name,age,sex)
        self.stu_id=stu_id
        self.grade=grade

    def tell(self):
        print("""-------info of student:---------
               name:%s
               age:%s
               sex:%s
               stu_id:%s
               grade=%s
         """ % (self.name, self.age, self.sex, self.stu_id, self.grade))





    def pay(self,account):
        print("%s paid account:$%d"%(self.name,account))



school1=school('北京大学','北京')

teacher1=Teacher('李老师',30,'男',5000,'Linux')
teacher2=Teacher('陈老师',23,'女',3000,'PHP')


student1=Student('小明',23,'女',1001,'python')
student2=Student('小露',25,'女',1002,'python')


teacher1.tell()

student1.tell()


school1.enroll(student1)

print(school1.students)
print(school1.students[0].name)
school1.students[0].pay(5000)