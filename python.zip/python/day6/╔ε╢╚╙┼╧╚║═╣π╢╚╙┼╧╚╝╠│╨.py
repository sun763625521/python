# -*-coding:utf-8-*-
# Author:sunhao

class A(object):
    def __init__(self):
        print("A")


class B(A):
    # def __init__(self):
    #     print("B")
    pass

class C(A):
    # def __init__(self):
    #     print("C")
    pass

class D(B,C):
    # def __init__(self):    #在python2中 经典类是按深度优先来继承的   新式类是按广度优先来继承的
    #     print("D")         #在python3中 经典类和新式类都是按广度优先来继承的
    pass


a=D()


