# -*-coding:utf-8-*-
# Author:sunhao

import socket
import os

server = socket.socket()

ip_port = ('127.0.0.1',6969)

server.bind(ip_port)

server.listen()

while True:

    conn,f = server.accept()
    print("new connect:",f)

    while True:
        print("等待新指令")

        data = conn.recv(1024)
        if not data:
            print("客户端断开")

            break
        print("执行指令",data)

        res = os.popen(data.decode()).read()


        print("before send",len(res.encode()))



        if len(res) == 0:
            res = "没有改指令，请重新输入:"

        conn.send(str(len(res.encode())).encode('utf-8'))   #先发数据大小给客户端    会发生粘包
        #
        client_ack=conn.recv(1024)     #解决粘包
        print(client_ack.decode())
        conn.send(res.encode("utf-8"))                  #再发数据

        print("send done")






server.close()







