# -*-coding:utf-8-*-
# Author:sunhao

import socketserver

class MyTCPHandler(socketserver.BaseRequestHandler):


        def handle(self):
            while True:

                try:

                    self.data=self.request.recv(1024).strip()

                    print(self.data)

                    self.request.sendall(self.data.upper())

                except ConnectionAbortedError as e:

                    print("出错额",e)
                    break

if __name__ == "__main__":

    HOST,PORT = '127.0.0.1',9999

    server=socketserver.ThreadingTCPServer((HOST,PORT),MyTCPHandler)

    server.serve_forever()
