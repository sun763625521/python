# -*-coding:utf-8-*-
# Author:sunhao

import socket,hashlib


client = socket.socket()
ip_port = ('127.0.0.1',6969)

client.connect(ip_port)

print("连接开始")
while True:

    get_file = input(">>>:").strip()

    if len(get_file) == 0:
        continue

    if get_file.startswith('get'):
        client.send(get_file.encode("utf-8"))
        server_response= client.recv(1024)  # 接受文件大小的长度
        print("文件打的大小", server_response)

        client.send("准备好接收了".encode('utf-8'))



        recived_size=0

        total_size=int(server_response.decode())
        filename=get_file.split()[1]
        f=open(filename+".new",'wb')
        m = hashlib.md5()

        while recived_size < total_size:

            if total_size -recived_size > 1024:

                size=1024
            else:
                size=total_size-recived_size


            data = client.recv(size)

            m.update(data)


            recived_size += len(data)  #每次收到的有可能小于1024 所以用len判断

            f.write(data)


        else:

            client_file_md5 = m.hexdigest()

            print("file recived done",recived_size)
            f.close()

        server_file_md5 = client.recv(1024)

        print("server file md5:",server_file_md5)
        print("server file md5:",client_file_md5)


client.close()


