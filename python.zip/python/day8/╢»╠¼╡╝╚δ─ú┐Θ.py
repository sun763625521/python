# -*-coding:utf-8-*-
# Author:sunhao


import importlib


lib=importlib.import_module("lib.aa")


lib.test()

print(lib.name)

assert type(lib.name) is str

print('ok')

print("okkk")

# lib = __import__("lib.aa")

# print(mod.aa.test)
#
# v=getattr(mod,"aa")
#
# print(v)