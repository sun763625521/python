# -*-coding:utf-8-*-
# Author:sunhao




import socket


ip_port = ('127.0.0.1',9999)

sk = socket.socket()

sk.connect(ip_port)

while True:
    msg=input(">>>>>>:")

    sk.send(msg.encode("utf-8"))

    data=sk.recv(1024)

    print(data)

sk.close()

