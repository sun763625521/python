# -*-coding:utf-8-*-
# Author:sunhao

import socket

ip_port=('localhost',6969)

client=socket.socket()

client.connect(ip_port)

while True:

    msg=input(">>:").strip()

    client.send(msg.encode("utf-8"))

    data=client.recv(1024)
    print(data.decode())
client.close()



