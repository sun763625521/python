# -*-coding:utf-8-*-
# Author:sunhao

# class Mytype(type):
#
#     def


class Foo(object):

    def __init__(self,name):
        self.name=name

    def __str__(self):

        return self.name



f=Foo("xiaoming")

print(f)
print(type(f))
print(type(Foo))
