# -*-coding:utf-8-*-
# Author:sunhao


def talk(self):
    print("%s is talking"%self)

class Dog(object):
    def __init__(self,name):

        self.name=name


    def eat(self):

        print("%s is eating .."%self.name)



d=Dog("xiao")

choice=input(">>:").strip()

# print(hasattr(d,choice))   #反射 hasattr 判断一个对象里是否有对应的字符串的属性方法映射
#
# print(d.eat)
# print(getattr(d,choice))
#
# getattr(d,choice)()        #根据字符串去获取obj对象里的对应的方法的内存地址

#
setattr(d,choice,talk) #设置成员 相当于d.choice=talk
v=getattr(d,choice)
v("xiaoming")
#delattr(d,choice)
