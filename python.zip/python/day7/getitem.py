# -*-coding:utf-8-*-
# Author:sunhao

class Foo(object):

    def __init__(self):

        self.data={}

    def __getitem__(self, item):
        print("get_item",item)
        return self.data.get(item)

    def __setitem__(self, key, value):
        print("__setitem",key,value)
        self.data[key]=value



    def __delitem__(self, key):
        print("__delitem",key)





obj=Foo()

obj['name']='sunhao'

# print(obj.data)
#
# print(obj['name'])

del obj["name"]