# -*-coding:utf-8-*-
# Author:sunhao

class Flight(object):
    def __init__(self,name):
        self.name=name


    def checking_status(self):

        print("checking flight %s status"%self.name)

        return 1

    @property
    def flight_status(self):

        status=self.checking_status()
        if status==0:
            print("flight has canceled")
        elif status==1:
            print("flight has arrived")
        else:
            print("cannot confirm the flight status...,please check later")

    @flight_status.setter  # 修改
    def flight_status(self, status):
        status_dic = {
            0: "canceled",
            1: "arrived",
            2: "departured"
        }


        print("\033[31;1mHas changed the flight status to \033[0m", status_dic.get(status))



f=Flight("东方航空")


f.flight_status
f.flight_status=2
print(type(Flight))

