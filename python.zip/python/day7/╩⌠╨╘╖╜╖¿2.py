# -*-coding:utf-8-*-
# Author:sunhao

class Dog(object):


    def __init__(self,name):

        self.name=name
        self.__food = None


    @property
    def eat(self):  #把一个方法变成一个静态属性

        print("%s is eating %s"%(self.name,self.__food))



d=Dog("xiaoming")


d.eat