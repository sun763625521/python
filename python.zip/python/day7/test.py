# -*-coding:utf-8-*-
# Author:sunhao
# import json
# list=[]
# with open('test','r') as f:
#     for item in f:
#         list.append(item.split())
#         # print(item)
# # print(list)
#
# with open('test1','r+') as f1:
#     list1=json.loads(f1.read())
#     print(list1)
#     print(type(list1))
#     list1.extend(list)
#     print(list1)
#     f1.seek(0)
#     print(f1.tell())
#     f1.truncate()
#     list2=json.dumps(list1)
#     print(list2)
#     print(type(list2))
#     f1.write(list2)

import time
list1=[1,2,3]
dict1={}
name="sunhao"
mounth=time.strftime("%Y-%m-%d",time.localtime())
times=time.strftime("%H-%M-%S",time.localtime())


dict1[name]={mounth:{times:list1}}
print(dict1[name])