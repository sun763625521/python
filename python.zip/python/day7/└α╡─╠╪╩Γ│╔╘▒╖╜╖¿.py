# -*-coding:utf-8-*-
# Author:sunhao

class Dog(object):
    '''类的属性方法
    '''
    name='jim'

    def __init__(self,name):
        self.name=name


    def __str__(self):

       return "__str_____"

    @classmethod      #类方法只能访问类变量  不能访问实例变量
    def eat(self):

        print("%s is eating %s"%(self.name,'food'))


d=Dog("小米")

# print(Dog.__doc__)
# print(Dog.__dict__)

print(d)