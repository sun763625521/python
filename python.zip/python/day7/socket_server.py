# -*-coding:utf-8-*-
# Author:sunhao
import socket

serve = socket.socket()

serve.bind(('localhost', 6969))

serve.listen()
print("我要开始等电话")

conn, addr = serve.accept()  # conn就是客户端链接过来而在服务器端为其生成的一个连接实例
print(conn, addr)

while True:
    data = conn.recv(1024)
    print(data.decode())

    conn.send(data.upper())

serve.close()
