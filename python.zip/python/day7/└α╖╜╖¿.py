# -*-coding:utf-8-*-
# Author:sunhao




class Dog(object):

    name = 'jim'
    n=11111
    def __init__(self,name):
        self.name=name
        self.n=None


    @classmethod           # 类方法只能访问类变量  不能访问实例变量
    def eat(self):
        print("%s is eating %s %d" % (self.name, 'food',self.n))


d=Dog("xiaoming")



print(d.n)

d.eat()

