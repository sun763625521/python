# -*-coding:utf-8-*-
# Author:sunhao

def test(self):
    print("%s test"%self.name)


class Dog(object):

    def __init__(self,name):
        self.name=name



    @staticmethod   #静态方法跟类没什么关系  相当于普通函数
    def eat(self):

        print("%s is eating food"%self.name)


d=Dog("xiaoming")    # 静态方法 只是名义上归类管理，实际上在静态方法里访问不了类或实例中的任何属性
d.eat(d)
test(d)

