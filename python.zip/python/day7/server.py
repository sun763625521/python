# -*-coding:utf-8-*-
# Author:sunhao

import socket


ip_port = ('127.0.0.1',7000)

sk = socket.socket()

sk.bind(ip_port)

sk.listen(5)

while True:

    conn, address = sk.accept()



    while True:

        print(conn, address)
        data=conn.recv(1024)
        print(data)
        if not data:
            print("客户端断开连接")
            break

        conn.send(data.upper())




sk.close()



