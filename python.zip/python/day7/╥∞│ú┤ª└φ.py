# -*-coding:utf-8-*-
# Author:sunhao

class Dog(object):
    def __init__(self,name):

        self.name=name


    def eat(self):

        print("%s is eating .."%self.name)

d=Dog("JIm")

# print(d.eat)
# choice=input(">>:").strip()
# print(hasattr(d,choice))
#
# func=getattr(d,choice)
# # print(func)
# func()


names=['jim','lucy']
data={}

s1='hello'

try:                             #异常处理
    open('t.txt')
    data['name']
    int(s1)
    names[2]


# except  IndexError as e :
#     print("no names[2]",e)
#
# except KeyError as k:
#     print("key error",k)

# except ValueError as e:
#     print(e)

except Exception as e:            #抓住所有异常错误
    print("出错了",e)


else:
    print("一切正常")

finally:
    print("不管有没有错，都执行")
















