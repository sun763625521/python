# -*-coding:utf-8-*-
# Author:sunhao

class TestExceptipon(Exception):
    def __init__(self,msg):
        self.msg=msg

    # def __str__(self):
    #
    #     return self.msg



try:
    raise TestExceptipon('数据库连不上')

except  TestExceptipon as e:
    print(e)
#
# while True:
#     num1 = input('num1:')
#     num2 = input('num2:')
#     try:
#         num1 = int(num1)
#         num2 = int(num2)
#         result = num1 + num2
#     except Exception as e:
#         print ('出现异常，信息如下：')
#         print (e)