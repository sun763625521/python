# -*-coding:utf-8-*-
# Author:sunhao


class Dog(object):



    def __init__(self,name):

        self.name=name
        self.__food = None

    def __call__(self, *args, **kwargs):
        print(args,kwargs)


    @property
    def eat(self):  #把一个方法变成一个静态属性

        print("%s is eating %s"%(self.name,self.__food))

    @eat.setter                #对方法赋值
    def eat(self,food):
        print('set to food',food)
        self.__food=food


    @eat.deleter
    def eat(self):
        del self.__food
        print('删')

    def __str__(self):
        return "%s"%self.name




d=Dog("xiaoming")

d.eat
d.eat='baozi'

d.eat
d()
# d(1,2,3,name=345)
#
#
# print(Dog.__dict__)  #打印类里的所有属性 不包括实例属性
#
# print(d.__dict__)  #打印所有实例属性 不包括类属性
#
#
# print(d)

print(d.__class__)