# -*-coding:utf-8-*-
# Author:sunhao

import paramiko

transport=paramiko.Transport('192.168.10.141',22)     #远程服务器为192.168.10.141

transport.connect(username='root',password='123456')

sftp = paramiko.SFTPClient.from_transport(transport)

# 将本地paramiko模块-ssh.py 上传至服务器 /tmp/paramiko模块

#sftp.put('paramiko模块-ssh.py', '/home/paramiko模块')

# 将服务器/tmp/zabbix_server.log 下载到本地

sftp.get('/tmp/zabbix_server.log', 'zabbix_server.log')

transport.close()