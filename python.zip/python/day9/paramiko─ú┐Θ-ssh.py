# -*-coding:utf-8-*-
# Author:sunhao

import paramiko

ssh= paramiko.SSHClient()   #创建ssh对象

# 允许连接不在know_hosts文件中的主机
ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())


#链接服务器
ssh.connect(hostname='192.168.10.141',port=22,username='root',password='123456')


#执行命令

stdin,stdout,stderr=ssh.exec_command("netstat -lpn;ps aux ")

#获取命令结果
result=stdout.read()

print(result.decode())


#关闭链接
ssh.close()


