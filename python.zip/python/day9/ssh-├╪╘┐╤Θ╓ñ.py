# -*-coding:utf-8-*-
# Author:sunhao

import  paramiko

private_key = paramiko.RSAKey.from_private_key_file('id_rsa')    #这是192.168.10.141上的私钥



ssh = paramiko.SSHClient()

ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())

ssh.connect(hostname='192.168.10.180',port=22,username='root',pkey=private_key)  #192.168.10.141上的公钥在10.180上放着


stdin,stdout,stderr=ssh.exec_command("netstat -lpn;df -h;ps aux |grep ssh")

#获取命令结果
result=stdout.read()

print(result.decode())


#关闭链接
ssh.close()
