# -*-coding:utf-8-*-
# Author:sunhao

import requests
import json

wether=requests.get('http://wthrcdn.etouch.cn/weather_mini?city=深圳')


wether.encodeing='utf8'

print(type(wether.text))

dict=json.loads(wether.text)
print(type(dict))