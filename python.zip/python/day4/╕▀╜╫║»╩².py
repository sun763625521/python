# -*-coding:utf-8-*-
# Author:sunhao
import time
def bar():
    time.sleep(3)
    print('in the bar')


def test1(func):
    start_time=time.time()

    func()
    stop_time=time.time()

    print('the func run time is %s'%(stop_time-start_time))


test1(bar)

