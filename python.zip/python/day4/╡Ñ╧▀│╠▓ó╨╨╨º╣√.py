# -*-coding:utf-8-*-
# Author:sunhao
import time
def consumer(name):
    print("%s准备吃包子了"%name)
    while True:
        baozi=yield

        print('包子[%s]来了，被%s吃了'%(baozi,name))


# c1=consumer('lily')
# c1.__next__()
#
# c1.send('韭菜')

def producer(name):
    c=consumer('A')
    c2=consumer('B')
    c.__next__()
    c2.__next__()
    print('%s开始做包子了'%name)
    for i in range(10):
        time.sleep(1)
        print('做了两个包子')
        c.send(i)
        c2.send(i)

producer('Tom')
