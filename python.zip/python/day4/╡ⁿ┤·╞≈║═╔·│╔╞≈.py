# -*-coding:utf-8-*-
# Author:sunhao

# a=[]
# for i in range(10):
#     a.append(i*2)
# print(a)

# b=[ i*2 for i in range(10)]
# print(b)

def fib(max):
    n,a,b=0,0,1
    while n<max:
        # print(b)
        yield b
        a,b=b,a+b
        n=n+1
#
#
gen=fib(10)
print(next(gen))
print(gen.__next__())

print(gen.__next__())
print(next(gen))

# a=[1,2,3,4,5,6]
# for index,i in enumerate(a):
#     print(index,i)
#     a[index]+=1
# print(a)

# b=[]
# for i in a:
#     b.append(i+1)
#
# # a=b
#
# print(b)

# G=(i*2 for i in range(10))
# print(next(G))
# print(next(G))

