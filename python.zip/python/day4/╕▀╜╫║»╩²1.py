# -*-coding:utf-8-*-
# Author:sunhao

import time
def bar():
    time.sleep(3)
    print('in the bar')


def test2(func):  #传进去的是函数的内存地址
    #print(func)
    return func   #返回值也是函数的内存地址

#t=test2(bar)      #接收函数内存地址
#t()               #加上小括号就执行该函数


tes=test2(bar)
print(tes)
print(bar)