# -*-coding:utf-8-*-
# Author:sunhao
# import pickle
#
# def sayhi(name):
#     print('hello',name)
#
# info={'name':'sunhao',
#     'age':18,
#       'func':sayhi}
#
# f=open('test.txt','wb')
#
# f.write(pickle.dumps(info))
# f.close()
#
import json

#dumps和loads只是在内存中转换

dic={'k1':'v1'}

dic1=json.dumps(dic) #将python的基本数据类型转换成字符串形式
print(type(dic))
print(type(dic1))


s1='{"k2":"v2"}'
dic2=json.loads(s1)  #将python的字符串形式转换成基本数据类型

print(type(s1))
print(type(dic2))



'''
json.dump()    具有写文件和读文件的功能
json.load()
'''
li=[11,22,33]
json.dump(li,open('db','w'))

ret=json.load(open('db','r'))
print(ret,type(ret))



