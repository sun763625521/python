# -*-coding:utf-8-*-
# Author:sunhao

# from collections import Iterable
#
# a=isinstance([],Iterable)
# b=isinstance((),Iterable)
# c=isinstance({},Iterable)
# d=isinstance('abc',Iterable)
# e=isinstance((i for i in range(10)),Iterable)
# f=isinstance(100,Iterable)
# print(a)
# print(b)
# print(c)
# print(d)
# print(e)
# print(f)

from collections import Iterator


a=isinstance(iter([]),Iterator)
b=isinstance((),Iterator)
c=isinstance({},Iterator)
d=isinstance('abc',Iterator)
e=isinstance((i for i in range(10)),Iterator)
f=isinstance(100,Iterator)
print(a)
print(b)
print(c)
print(d)
print(e)
print(f)








