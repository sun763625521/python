# -*-coding:utf-8-*-
# Author:sunhao

import time

def timer(func):
    def deco(*args,**kwargs):
        start_time=time.time()
        func(*args,**kwargs)
        end_time=time.time()
        print('the func run time is %s'%(end_time-start_time))
    return deco
@timer
def test1(*args,**kwargs):
    time.sleep(3)
    print('in the test1')
    print(args,kwargs)
@timer
def test2(age=18):
    time.sleep(3)
    print('in the test2')
    print(age)
#test1=timer(test1)
#test2=timer(test2)



test1(1,2,3,age=18)

