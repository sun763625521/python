# -*-coding:utf-8-*-
# Author:sunhao
def test(n):
    print(n)

a=lambda n:print(n)
a(5)

res=lambda n:n*2

print(res(11))

re=filter(lambda n:n*2,range(10))
for i in re:
    print(i)

