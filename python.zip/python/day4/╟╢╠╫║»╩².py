# -*-coding:utf-8-*-
# Author:sunhao

def foo():
    print('in the foo')
    def bar():                #函数嵌套是在函数内部用def去声明一个函数
        print('in the bar')

    bar()      #局部变量不能再外部调用，只能在函数内部调用

foo()


x=0
def grandpa():
    x=1
    print(x)
    def dad():
        x=2
        print(x)
        def son():
            x=3
            print (x)
        son()
    dad()
grandpa()
