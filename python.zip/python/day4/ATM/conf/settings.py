# -*-coding:utf-8-*-
# Author:sunhao
def test():
    print('test')