# -*-coding:utf-8-*-
# Author:sunhao

def login():
    print('Welcome to ATM')