# -*-coding:utf-8-*-
# Author:sunhao

def func():
    print('in the func')

def test():
    print('in the test')
    func()
test()


