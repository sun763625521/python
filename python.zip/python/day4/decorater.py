# -*-coding:utf-8-*-
# Author:sunhao

import time

def timer(func):
    def deco(*args,**kwargs):
        start_time=time.time()
        func(*args,**kwargs)
        stop_time=time.time()
        print('the func run time is %s'%(stop_time-start_time))
    return deco


@timer
def test1(*args,**kwargs):
    time.sleep(1)
    print('in the test1')
    print(args,kwargs)
@timer
def test2():
    time.sleep(1)
    print('in the test2')

#test1=timer(test1)  等于 @timer
#test2=timer(test2)  等于 @timer
# test1()    #相当于执行deco
# test2()

test1(1,2,3,AGE=19)
