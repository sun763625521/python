# -*-coding:utf-8-*-
# Author:sunhao
def test():
    pass
print(callable(test))
a=chr(98)
print(a)
b=ord('@')
print(b)
a=[11,11,2,3,3,4,3]
v=set(a)
print(v)

