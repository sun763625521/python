# -*-coding:utf-8-*-
# Author:sunhao
#pickle 只能python使用  它支持所有数据类型   这就是pickle和json 的数据类型 可以对复杂数据类型做操作
#缺点是仅适用于python


import pickle

li=[11,22,33]

ret=pickle.dumps(li)

print(ret)

result=pickle.loads(ret)
print(result)

pickle.dump(li,open('db1','wb'))
ret1=pickle.load(open('db1','rb'))
print(ret1)


class foo():
    def __init__(self):
        pass

f=foo()
ret2=pickle.dumps(f)
print(ret2)

ret3=pickle.loads(ret2)
print(ret3)










