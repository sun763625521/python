# -*- coding:utf-8 -*-
# Author:sunhao

import getpass

_username='sunhao'
_password='abc123'

username = input("usename:")
#password = input("password:")
password = getpass.getpass("请输入你的密码：")



if _username==username and password == _password:
    print("Welcome user {name} login...".format(name=_username))
else:
    print("Invalid username or password")


