# -*-coding:utf-8-*-
# Author:sunhao

import password

import sys
print(sys.argv)