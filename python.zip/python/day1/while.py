# -*- coding:utf-8 -*-
# Author:sunhao
age_of_oldboy=56
count=0
while True:
    if count ==4:
        break
    guss_age=int(input('guess_age:'))
    if guss_age == age_of_oldboy:
        print('you got it')
        break
    elif guss_age > age_of_oldboy:
        print('bigger')
    else:
        print('smaller')
    count+=1