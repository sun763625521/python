# -*- coding:utf-8 -*-
# Author:sunhao

'''
name = "sunhao"
num = 10
'''

print("My name is %d %s" %(num, name))


