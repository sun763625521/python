# -*-coding:utf-8-*-
# Author:sunhao
for i in range(10):

    if i >5:

        print('continue!')
        break  #跳出整个循环  结束整个循环
    print(i)
''' elif i<5:

        print('Continue!')
        continue   #只是跳出本次循环'''