# -*- coding:utf-8 -*-
# Author:sunhao

name='你好，世界'
print (name)
name ='Tom'
name1=name
print(name,name1)
name ='jake'
print(name1)