# -*- coding:utf-8 -*-
# Author:sunhao

print ('hello word!')
