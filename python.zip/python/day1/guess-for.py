# -*- coding:utf-8 -*-
# Author:sunhao


age_of_oldboy=56

for i in range(3):

    guss_age=int(input('guess_age:'))
    if guss_age == age_of_oldboy:
        print('you got it')
        break
    elif guss_age > age_of_oldboy:
        print('bigger')
    else:
        print('smaller')

else:
    print("you have tried too many times")


