# -*- coding:utf-8 -*-
# Author:sunhao


'''age_of_oldboy=56
count=0
while count <2:

    guss_age=int(input('guess_age:'))
    if guss_age == age_of_oldboy:
        print('you got it')
        break
    elif guss_age > age_of_oldboy:
        print('bigger')
    else:
        print('smaller')
    count+=1
    if count ==2:
        countinue_confirm=input('do you want to keep guessing..?')
        if countinue_confirm != 'no':
            count=0

else:
    print("you have tried too many times")

'''
for i in range(10):
    print('loop',i)
