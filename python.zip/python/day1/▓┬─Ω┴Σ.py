# -*-coding:utf-8-*-
# Author:sunhao
age_of_me = 26

count = 0
# 猜年龄最多只让猜5次

while count < 2:

    guess_age = int(input('请输入要猜的名字：'))

    if guess_age == age_of_me:
        print('恭喜你，猜对了！')
    elif guess_age < age_of_me:
        print("smaller")
    else:
        print('bigger')

    count += 1
    if count == 2:
        continue_guess = input('是否继续：请输入yes  or no')
        if continue_guess == 'yes':
            count = 0

else:
    print("密码多次输错")