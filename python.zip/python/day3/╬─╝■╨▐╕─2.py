# -*-coding:utf-8-*-
# Author:sunhao
import time
f = open('yesterday','r',encoding='utf-8')



for line in f:
   print(line,type(line))
   time.sleep(1)