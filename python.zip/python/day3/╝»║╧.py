# -*-coding:utf-8-*-
# Author:sunhao

list_1=[1,4,5,7,3,6,7,9]

list_1=set(list_1)       #创建集合  集合也是无序的

print(list_1,type(list_1))
'''
list_2=set([2,6,0,66,22,8,4])

print(list_1,list_2)


print(list_1.intersection(list_2)) #求交集


print(list_1.union(list_2))   #求并集 两个集合去重合并

print(list_1.difference(list_2))  #差集  list_1中有 list_2中没有的元素
print(list_2.difference(list_1))    #差集  list_2中有 list_1中没有的元素

#子集
print(list_1.issubset(list_2))  # 判断list_1是否是list_2的子集

list_3=set([1,3,7])

print(list_3.issubset(list_1))

#父集
print(list_1.issuperset(list_2)) # 判断list_1是否是list_2的父集

#对称差集

print(list_1.symmetric_difference(list_2))

list_4=set([1,4,6])
print(list_3.isdisjoint(list_4))   #如果两个集合没有交集返回True 否则返回False



#运算符

print(list_1 & list_2) #交集

print(list_1 | list_2) #并集

print(list_1 - list_2)  #差集

print(list_1 ^ list_2)  #对称 差集


# 集合基本操作
# 集合中是没有插入的，只能添加
'''
list_1.add(199)     # 添加一项

list_5={100,200}
list_1.update(list_5)

print(list_1)

list_1.remove(1)  # 删除
print(list_1)
list_1.discard(9000)
print(list_1)