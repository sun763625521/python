
# -*-coding:utf-8-*-
# Author:sunhao

def stu_info(name, age,course,country='CN'):
    print("----注册学生信息------")
    print("姓名:", name)
    print("age:", age)
    print("国籍:", country)
    print("课程:", course)


#stu_info("王山炮", 22, "CN", "python_devops")
#stu_info("张叫春", 21, "CN", "linux")
#stu_info("刘老根", 25, "CN", "linux")

stu_info('Jim',16,'linux')

def test(x,y,*args):
    print(x,y,args)


test(1,2,3,4,5,6)


def test1(x,y,*args,**kwargs):
    print(x,y,args,kwargs)
    print()

test1(1,2)