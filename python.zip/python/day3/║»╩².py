# -*-coding:utf-8-*-
# Author:sunhao

#下面这段代码
a,b=2,4
c=a**b
print(c)

#改用函数写

def cal(x,y):
    result=x**y
    return result   #返回函数执行结果


c=cal(a,b)     #结果赋值给c变量
print(c)



def test1():
    print('in the test1')

def test2():
    print('in the test2')
    return 0

def test3():
    print('in the test3')
    return 1,'hello',['Tom','Jim'],{'age':18}

x=test1()
y=test2()
z=test3()

print(x)
print(y)
print(z)


def calc(n):
    print(n)
    if int(n / 2) == 0:
        return n
    return calc(int(n / 2))


calc(10)



