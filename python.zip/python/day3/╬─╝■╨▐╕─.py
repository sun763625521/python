# -*-coding:utf-8-*-
# Author:sunhao

f = open('yesterday','r',encoding='utf-8')

f_new = open('yesterday.bak','w',encoding='utf-8')

for line in f:
    if "肆意的快乐" in line:
        line=line.replace("肆意的快乐",'肆意的痛苦')

    f_new.write(line)

f.close()
f_new.close()