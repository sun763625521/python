# -*-coding:utf-8-*-
# Author:sunhao
name='Jim'
def test():
    name='Lucy'
    print(name)

def test1():
    test()

test1()