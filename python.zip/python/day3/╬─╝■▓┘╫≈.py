# -*-coding:utf-8-*-
# Author:sunhao

f = open('yesterday','r+',encoding='utf-8') #f为文件句柄

#f.write("斧子科技\n")
#f.write('斧子科技有限公司')
'''
count=0
for line in f:
    if count==9:

        print("----------分隔符----------")

        count+=1
        continue
    print(line)
    count+=1
'''
#print(f.readlines())
#print(f.tell())

#print(f.readlines())

#print(f.tell())


#print(f.read(16))

#print(f.tell())

#f.seek(0)
#print(f.tell())
'''
for index,line in enumerate(f.readlines()):

    if index == 9:
        print('-------分隔符 - -----')
        continue
    print(line)'''

f.seek(19)

print(f.readline())


print(f.encoding)

f.flush()

f.truncate(20)

import sys,time
for i in range(100):
    sys.stdout.write('#')
    sys.stdout.flush()

    time.sleep(1)

