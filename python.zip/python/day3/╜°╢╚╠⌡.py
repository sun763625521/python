# -*-coding:utf-8-*-
# Author:sunhao

import sys,time

for i in range(100):
    sys.stdout.write('#')
    #print (i)

    sys.stdout.flush()
    time.sleep(0.1)