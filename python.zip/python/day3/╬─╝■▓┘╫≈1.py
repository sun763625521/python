# -*-coding:utf-8-*-
# Author:sunhao

f=open('today','r+',encoding='utf-8')

f.write('today is a good day----1\n')

f.write('today is a good day----2')

f.write('today is a good day----3\n')

print(f.tell())
#print(f.readline())

f.seek(10)
print(f.tell())


f.write('yestodayyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyy')

print(f.tell())



