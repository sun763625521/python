
# Author:sunhao
import sys
print(sys.getdefaultencoding())

s='斧子科技'

s_gbk=s.encode('gbk')



print(s_gbk)

print(s.encode())

gbk_to_utf8=s_gbk.decode('gbk').encode('utf-8')

print(gbk_to_utf8)

print(s.encode('utf8').decode('utf8'))