
import sys
print(sys.getdefaultencoding())

msg='天安门'

msg_to_gb2312=msg.encode('gb2312')

print(msg_to_gb2312)

gb2312_to_unicode=msg_to_gb2312.decode('gb2312')
gb2312_to_utf8=msg_to_gb2312.decode('gb2312').encode('utf-8')

print(gb2312_to_unicode)

print(gb2312_to_utf8)

print(msg)