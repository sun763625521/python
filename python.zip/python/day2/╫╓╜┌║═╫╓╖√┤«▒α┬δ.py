# -*-coding:utf-8-*-
# Author:sunhao
name ='中国'
name1=name.encode('utf-8')
print (name1)
name2=name1.decode()
print (name2)