# -*-coding:utf-8-*-
# Author:sunhao

province={

     '广东省':{
              '深圳市':['南山区','龙岗区','福田区'],
              '广州市':['荔湾区','海珠区','天河区'],
              '惠州市':['惠阳区','惠城区','惠东县']
             },

     '浙江省':{
              '杭州市':['西湖区','上城区','下城区'],
              '宁波市':['江北区','镇海区'],
              '嘉兴市':['南湖区','秀洲区']`
             }
}


exit_flag=False

while not exit_flag:
     for i in province:
         print(i)
     choice=input('请选择省份: ')

     if choice in province:
         while not exit_flag:
             for i2 in province[choice]:
                 print(i2)
             choice2=input("请选择城市：")


             if choice2 in province[choice]:
                while not exit_flag:
                    for i3 in province[choice][choice2]:
                        print(i3)

                    choice3=input('最后一层,按b返回')
                    if choice3 =='b':
                        break
                    elif choice3 =='q':
                        exit_flag=True

             if choice2=='b':
                 break

     if choice =='b':
        pass
     elif choice == 'q':
         exit_flag = True



