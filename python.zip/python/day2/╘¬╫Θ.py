# -*-coding:utf-8-*-
# Author:sunhao

names=('Tom','Jack')

count=names.index('Jack')

print(count)