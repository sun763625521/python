# -*-coding:utf-8-*-
# Author:sunhao

product_list=[('Iphone',5800),
              ('Mac Pro',12000),
              ('Bike',800),
              ('Watch',10600),
              ('coffee',31)
              ]
shopping_list=[]

salary=input('请输入你的工资：')
if salary.isdigit():
    salary=int(salary)
    while True:
        for index,item in enumerate(product_list):
            print(index,item)
        user_choice=input("请选择要买的商品：")
        if user_choice.isdigit():
            user_choice=int(user_choice)
            if user_choice<len(product_list) and user_choice >=0:
                p_item=product_list[user_choice]
                print(p_item)
                if p_item[1] <= salary:
                    shopping_list.append(p_item)
                    salary -= p_item[1]
                    print('%s已添加至购物车 ,余额为%d'%(p_item[0],salary))

                else:
                    print("\033[41;1m你的余额只剩%s\033[0m"%salary)

            else:
                print("商品不存在")


        elif user_choice=='q':
            print("-------shoppinglist------")
            for p in shopping_list:
                print(p[0])
            print('-------------------------')
            print('Your current balance:%s'%salary)
            exit()
        else:
            print('Invalid choice')






