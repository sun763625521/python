# -*-coding:utf-8-*-
# Author:sunhao

name ='my name is sunhao'

print(name.capitalize())   #首字母大写
print(name.count("m"))     #统计m出现次数
print(name.center(50,'-')) #打印50个字符把name放中间
print(name.endswith('ao')) #判断一个字符串是否以ao结尾
print(name.find('name'))   #查找name，找到返回其索引，找不到返回-1
print(name[name.find('name'):])


name_info='my name is {_name} and i am {_age} old'  #format可以这样用
print(name_info.format(_name='sunhao',_age=18))

print(name_info.format_map({'_name':'sunhao','_age':18}))   #format_map 字典用法

print('9aA'.isalnum())  #包含数字和字母
print('abA'.isalpha())  #包含纯英文字符

print('123'.isdigit())   #判断是否是整数

print('1A'.isidentifier())  #判断是不是合法的变量名

print('abc'.islower())    #判断是否是小写

print('33a'.isupper())     #判断是否是大写

print('#'.join(['1','2','3']))

print(name.ljust(50,'*'))   #表示长度50 不够右边*号补上

print(name.rjust(50,'-'))    #表示长度50 不够左边-号补上

print('SUNHAO'.lower())      #大写变小写
print('sunhao'.upper())       #小写变大写

print('SunHao'.lstrip())  #去掉左边空行和回车
print('SunHao'.rstrip())  #去掉右边空行和回车


print('sunhao'.replace('u','U',1))  #替换1次

print('sunhaoshaoa'.rfind('a')) #找到最右边目标的索引

print('sun test'.split('t'))   #以t切分  t没有了
print('Sunhao'.swapcase())     #大小写互换
