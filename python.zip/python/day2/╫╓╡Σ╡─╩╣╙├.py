# -*-coding:utf-8-*-
# Author:sunhao

info={
      '01':'Tom',
      '02':'Jim',
      '03':'Lucy',
      '04':'Lily'
}

print(info['01'])

info['01']='HanMeimei'
info['05']='xiaohong'

print(info)

del info['05']

print(info)

info.pop('04')
print(info)





















