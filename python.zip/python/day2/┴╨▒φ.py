# -*-coding:utf-8-*-
# Author:sunhao
'''names=['Xiaoming','Lucy','Tom','Lily']
print(names[0:2])
print(names[-2:-1])
print(names[-2:])

list1=['banana', 'peach','watermelon','banana','peach','apple','tomato','banana']
count=list1.count('banana') #统计列表中banana 的数量
print(count)'''
import copy
list1=['apple',['orange','peach']]

list2=list1.copy()


list1[0]='water'

print(list1,list2)


